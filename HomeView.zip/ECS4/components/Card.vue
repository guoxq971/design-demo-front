<template>
  <div class="card">
    <div class="title">{{ title }}</div>
    <div class="list">
      <div
        class="item"
        v-for="item in list"
        @mouseenter="mouseenter(item)"
        @mouseleave="mouseleave(item)"
      >
        <div v-if="color" :style="{ color: item.color }">{{ item.label }}</div>
        <template v-else>
          <div class="label-item">{{ item.label }}：</div>
          <div>{{ item.value }}</div>
        </template>
      </div>
    </div>
  </div>
</template>

<script setup>
  const props = defineProps({
    list: Array,
    color: { type: Boolean, default: false },
    title: String,
    mouseenter: Function,
    mouseleave: Function,
  });
</script>

<style scoped lang="scss">
  .card {
    display: flex;
    flex-direction: column;
    .title {
      font-weight: bold;
      font-size: 22px;
    }
    .list {
      display: flex;
      .item {
        display: flex;
        align-items: center;
        margin-right: 8px;
        border: 1px solid;
        height: 30px;
        padding: 2px 4px;
        .label-item {
          margin-right: 4px;
          display: flex;
          justify-content: center;
          align-items: center;
          white-space: nowrap;
        }
        .color-chunk {
          width: 30px;
          height: 30px;
        }
      }
    }
  }
</style>
