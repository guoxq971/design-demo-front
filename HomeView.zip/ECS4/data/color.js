import { fees } from '@/ECS4/data/fee';

// 灰色,绿色,蓝色,紫色，橙色
export const feeColors = {
  [fees.fee1]: 'rgb(161 159 159)',
  [fees.fee2]: 'rgb(78 197 78)',
  [fees.fee3]: 'rgb(121 121 245)',
  [fees.fee4]: '#ff00ff',
  [fees.fee5]: '#ff8000',
};

export const feeColorList = [
  //
  { label: '费用1', value: fees.fee1, color: feeColors[fees.fee1] },
  { label: '费用2', value: fees.fee2, color: feeColors[fees.fee2] },
  { label: '费用3', value: fees.fee3, color: feeColors[fees.fee3] },
  { label: '费用4', value: fees.fee4, color: feeColors[fees.fee4] },
  { label: '费用5', value: fees.fee5, color: feeColors[fees.fee5] },
];
