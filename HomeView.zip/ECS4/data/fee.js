import { feeColors } from '@/ECS4/data/color';

export const fees = {
  fee1: 1,
  fee2: 2,
  fee3: 3,
  fee4: 4,
  fee5: 5,
};

export const feeList = [
  //
  { label: '费用1', value: fees.fee1 },
  { label: '费用2', value: fees.fee2 },
  { label: '费用3', value: fees.fee3 },
  { label: '费用4', value: fees.fee4 },
  { label: '费用5', value: fees.fee5 },
];
