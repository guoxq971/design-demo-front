// 羁绊类型
export const jobTypes = {
  job1: '职业-1',
  job2: '种族-2',
  job3: '特殊-3',
};

// 羁绊类型数组
export const jobTypeList = [
  //
  { id: 1, type: jobTypes.job1 },
  { id: 2, type: jobTypes.job2 },
  { id: 3, type: jobTypes.job3 },
];

// 羁绊
export const jobList = [
  //
  { id: 1, name: '魔神使者', type: jobTypes.job1, fetter: '3/5/7/9' },
  { id: 2, name: '小蜜蜂', type: jobTypes.job1, fetter: '3/5/7' },
  { id: 3, name: '时间学派', type: jobTypes.job1, fetter: '3/6/8/10' },
  { id: 27, name: '次元术士', type: jobTypes.job1, fetter: '3/6/8/10' },
  { id: 4, name: '花仙子', type: jobTypes.job1, fetter: '2/4/6/9' },
  { id: 5, name: '龙族', type: jobTypes.job1, fetter: '2/3' },
  { id: 6, name: '诅咒女巫', type: jobTypes.job1, fetter: '2/4/6/8' },
  { id: 7, name: '咖啡甜心', type: jobTypes.job1, fetter: '2/4/6' },
  { id: 8, name: '冰霜', type: jobTypes.job1, fetter: '3/5/7/9' },
  { id: 9, name: '命运之子', type: jobTypes.job1, fetter: '2/3/4/5' },
  { id: 10, name: '炎魔', type: jobTypes.job1, fetter: '2/3/4/5' },
  { id: 11, name: '德鲁伊', type: jobTypes.job3, fetter: '1' },
  { id: 12, name: '魔战士', type: jobTypes.job2, fetter: '3/5/7/9' },
  { id: 13, name: '重装战士', type: jobTypes.job2, fetter: '2/4/6' },
  { id: 14, name: '换形师', type: jobTypes.job2, fetter: '2/4/6/8' },
  { id: 15, name: '堡垒卫士', type: jobTypes.job2, fetter: '2/4/6/8' },
  { id: 16, name: '猎手', type: jobTypes.job2, fetter: '2/4/6' },
  { id: 17, name: '法师', type: jobTypes.job2, fetter: '3/5/7/9' },
  { id: 18, name: '术师', type: jobTypes.job2, fetter: '2/4' },
  { id: 19, name: '学者', type: jobTypes.job2, fetter: '2/4/6' },
  { id: 20, name: '狂暴战士', type: jobTypes.job2, fetter: '2/4/6' },
  { id: 21, name: '强袭枪手', type: jobTypes.job2, fetter: '2/4/6' },
  { id: 22, name: '复苏者', type: jobTypes.job2, fetter: '2/3/4/5' },
  { id: 23, name: '狂暴蔷薇', type: jobTypes.job3, fetter: '1' },
  { id: 24, name: '蝙蝠女王', type: jobTypes.job3, fetter: '1' },
  { id: 25, name: '最佳好友', type: jobTypes.job3, fetter: '1' },
  { id: 26, name: '飞升者', type: jobTypes.job3, fetter: '1' },
];
