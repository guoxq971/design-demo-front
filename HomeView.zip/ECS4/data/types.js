export const types = {
  ad: 'ad',
  adc: 'adc',
  ap: 'ap',
  apc: 'apc',
  hp: 'hp',
};
export const typeList = [
  //
  { label: '物理前排输出', value: types.ad },
  { label: '物理后排输出', value: types.adc },
  { label: '法系前排输出', value: types.ap },
  { label: '法系后排输出', value: types.apc },
  { label: '前排防御', value: types.hp },
];
