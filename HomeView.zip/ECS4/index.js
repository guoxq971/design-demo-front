import { feeList, fees } from '@/ECS4/data/fee';
import { typeList, types } from '@/ECS4/data/types';
import { jobList, jobTypes, jobTypeList } from '@/ECS4/data/jobList';
import { unitList } from '@/ECS4/data/unit';
import { feeColorList, feeColors } from '@/ECS4/data/color';

export function test() {
  const getJobId = jobId => `job-${jobId}`;
  const getJobName = jobName => `job-${jobName}`;
  const getJobNames = (job1Name, job2Name) =>
    `jobNames-${job1Name}-${job2Name}`;
  const getFeeId = feeId => `fee-${feeId}`;
  const getUnitType = unitType => `unitType-${unitType}`;
  const getUnitId = unitId => `unitId-${unitId}`;
  const getUnitName = unitName => `unitName-${unitName}`;
  const get = {
    job: {
      id: getJobId,
      name: getJobName,
      names: getJobNames,
    },
    fee: {
      id: getFeeId,
    },
    unit: {
      type: getUnitType,
      id: getUnitId,
      name: getUnitName,
    },
  };
  const jobMap = new Map();
  const unitMap = new Map();

  jobList.forEach(job => {
    // 羁绊类型<typeName, job>
    if (!jobMap.has(job.type)) {
      jobMap.set(job.type, [job]);
    } else {
      jobMap.get(job.type).push(job);
    }

    // 羁绊名称<jobName, job>
    jobMap.set(job.name, job);

    // 羁绊id<jobId, job>
    jobMap.set(getJobId(job.id), job);
  });

  unitList.forEach(unit => {
    // unit的jobs转换为jobList
    unit.jobList = unit.jobs.map(jobId => jobMap.get(getJobId(jobId)));
    // unit的jobs转换为jobMap
    unit.jobMap = new Map();
    unit.jobList.forEach(job => {
      unit.jobMap.set(getJobId(job.id), job);
      unit.jobMap.set(getJobName(job.name), job);
    });

    // 添加费用颜色
    unit.feeColor = feeColors[unit.fee];

    // 费用<fee, unit>
    if (!unitMap.has(getFeeId(unit.fee))) {
      unitMap.set(getFeeId(unit.fee), [unit]);
    } else {
      unitMap.get(getFeeId(unit.fee)).push(unit);
    }

    unit.jobList.forEach(job => {
      const jobNameKey = get.job.name(job.name);
      const jobIdKey = get.job.id(job.id);

      // 职业<jobId, unit>
      if (!unitMap.has(jobIdKey)) {
        unitMap.set(jobIdKey, [unit]);
      } else {
        unitMap.get(jobIdKey).push(unit);
      }

      // 职业名称<jobName, unit>
      if (!unitMap.has(jobNameKey)) {
        unitMap.set(jobNameKey, [unit]);
      } else {
        unitMap.get(jobNameKey).push(unit);
      }
    });

    // 奕子类型<unitType, unit>
    if (!unitMap.has(getUnitType(unit.type))) {
      unitMap.set(getUnitType(unit.type), [unit]);
    } else {
      unitMap.get(getUnitType(unit.type)).push(unit);
    }

    // 奕子id<unitId, unit>
    unitMap.set(getUnitId(unit.id), unit);

    // 奕子名称<unitName, unit>
    unitMap.set(getUnitName(unit.name), unit);
  });

  // 职业1和职业2的组合<jobNames, unit[]>
  jobMap.get(jobTypes.job2).forEach(job2 => {
    jobMap.get(jobTypes.job1).forEach(job1 => {
      const cellUnitList = unitMap
        .get(get.job.name(job1.name))
        .filter(unit => unit.jobMap.get(get.job.name(job2.name)));
      if (cellUnitList.length) {
        unitMap.set(get.job.names(job1.name, job2.name), cellUnitList);
      }
    });
  });

  console.log('jobMap', jobMap);
  console.log('unitMap', unitMap);
  return {
    jobMap,
    unitMap,
    get,
  };
}
