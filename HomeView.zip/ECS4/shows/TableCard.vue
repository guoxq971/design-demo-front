<template>
  <div class="table">
    <!--row-header-->
    <div class="table-header-row">
      <div
        class="cell"
        v-for="job in jobMap.get(jobTypes.job1)"
        :class="{ light: headerHoverLight(job), click: headerClickLight(job) }"
        @click="clickJob(job)"
        @mouseenter="mouseenter(job)"
        @mouseleave="mouseleave(job)"
      >
        <span>{{ job.name }}</span>
        <span class="fetter">{{ job.fetter }}</span>
      </div>
    </div>
    <div class="table-body">
      <!--col-header-->
      <div class="table-header-col">
        <div
          class="cell"
          v-for="job in jobMap.get(jobTypes.job2)"
          :class="{
            light: headerHoverLight(job),
            click: headerClickLight(job),
          }"
          @click="clickJob(job)"
          @mouseenter="mouseenter(job)"
          @mouseleave="mouseleave(job)"
        >
          <span>{{ job.name }}</span>
          <span class="fetter">{{ job.fetter }}</span>
        </div>
      </div>
      <!--单元格-->
      <div class="rows" v-for="job2 in jobMap.get(jobTypes.job2)">
        <div
          class="cell"
          v-for="job1 in jobMap.get(jobTypes.job1)"
          @mouseenter="mouseenter(job1, job2)"
          @mouseleave="mouseleave(job1, job2)"
          @click="clickCell(job1, job2)"
          :class="{
            light: cellHoverLight(job1, job2),
            click: cellClickLight(job1, job2),
          }"
        >
          <div
            v-for="item in unitMap.get(get.job.names(job1.name, job2.name))"
            :style="{ color: item.feeColor }"
          >
            <span>{{ item.name }}</span>
            <span>,</span>
            <span>{{ item.type }}</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
  import { computed, defineProps, reactive, ref } from 'vue';
  import { jobTypes } from '@/ECS4/data/jobList';
  import { test } from '@/ECS4';
  const props = defineProps({
    /**@type {Set} 高亮列表-职业*/
    lightJobMap: Set,
    /**@type {Set} 高亮列表-费用*/
    lightFeeMap: Set,
    /**@type {Set} 高亮列表-职业类型*/
    lightTypeMap: Set,
  });
  const { jobMap, unitMap, get } = test();
  const checkJobMap = ref(new Set());
  const lightJobMap = computed(() => props.lightJobMap);
  const lightFeeMap = computed(() => props.lightFeeMap);
  const lightTypeMap = computed(() => props.lightTypeMap);

  // cell高亮-费用-hover
  const cellFeeHoverLight = computed(() => (job1, job2) => {
    const unitList = unitMap.get(get.job.names(job1.name, job2.name));
    return unitList?.some(unit => lightFeeMap.value.has(unit.fee));
  });

  // cell高亮-类型-hover
  const cellTypeHoverLight = computed(() => (job1, job2) => {
    const unitList = unitMap.get(get.job.names(job1.name, job2.name));
    return unitList?.some(unit => lightTypeMap.value.has(unit.type));
  });

  // header高亮-click
  const headerClickLight = computed(() => {
    return job => checkJobMap.value.has(job.name);
  });

  // 单元格高亮-click
  const cellClickLight = computed(() => (job1, job2) => {
    return checkJobMap.value.has(job1.name) || checkJobMap.value.has(job2.name);
  });

  // header高亮-hover
  const headerHoverLight = computed(() => job => {
    const hoverLight = lightJobMap.value.has(job.name);
    return hoverLight || headerClickLight.value(job);
  });

  // 单元格高亮-hover
  const cellHoverLight = computed(() => (job1, job2) => {
    const hoverLight =
      lightJobMap.value.has(job1.name) || lightJobMap.value.has(job2.name);
    const clickLight = cellClickLight.value(job1, job2);
    const feeHoverLight = cellFeeHoverLight.value(job1, job2);
    const typeHoverLight = cellTypeHoverLight.value(job1, job2);
    return hoverLight || clickLight || feeHoverLight || typeHoverLight;
  });

  // 点击header
  function clickJob(job) {
    checkJobMap.value.has(job.name)
      ? checkJobMap.value.delete(job.name)
      : checkJobMap.value.add(job.name);
  }

  // 点击cell
  function clickCell(job1, job2) {
    const hasJob1 = checkJobMap.value.has(job1.name);
    const hasJob2 = checkJobMap.value.has(job2.name);
    if (hasJob1 && hasJob2) {
      checkJobMap.value.delete(job1.name);
      checkJobMap.value.delete(job2.name);
    } else {
      !hasJob1 && checkJobMap.value.add(job1.name);
      !hasJob2 && checkJobMap.value.add(job2.name);
    }
  }

  // 鼠标经过单元格
  function mouseenter(job1, job2) {
    job1 && lightJobMap.value.add(job1.name);
    job2 && lightJobMap.value.add(job2.name);
  }
  function mouseleave(job1, job2) {
    job1 && lightJobMap.value.delete(job1.name);
    job2 && lightJobMap.value.delete(job2.name);
  }
</script>

<style scoped lang="scss">
  $light: rgba(61, 61, 61, 0.6);
  $click: rgba(61, 61, 61, 1);
  .light {
    background-color: $light !important;
  }
  .click {
    background-color: $click !important;
  }
  // 表格
  .table {
    $cellWidth: 120px;
    $cellHeight: 50px;
    .fetter {
      font-size: 12px;
    }
    .table-body {
      position: relative;
    }
    .table-header-col {
      position: absolute;
      left: -$cellWidth;
    }
    .rows,
    .table-header-row {
      display: flex;
      flex-wrap: wrap;
    }
    .cell {
      width: $cellWidth;
      height: $cellHeight;
      border: 1px solid;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
    }
  }
</style>
