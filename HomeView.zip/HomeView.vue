<template>
  <div class="home">
    <div class="flex mb-gap">
      <Card
        title="费用列表"
        :list="feeColorList"
        color
        :mouseenter="item => mouseenter(item, t.fee)"
        :mouseleave="item => mouseleave(item, t.fee)"
      />
      <Card
        title="奕子类型"
        :list="typeList"
        :mouseenter="item => mouseenter(item, t.type)"
        :mouseleave="item => mouseleave(item, t.type)"
      />
    </div>
    <div class="flex">
      <!--奕子表格-->
      <TableCard
        :lightJobMap="lightJobMap"
        :lightFeeMap="lightFeeMap"
        :lightTypeMap="lightTypeMap"
      />
    </div>
  </div>
</template>

<script setup>
  import { computed, ref } from 'vue';
  import { feeColorList, feeColors } from '@/ECS4/data/color';
  import { typeList, types } from '@/ECS4/data/types';
  import { feeList, fees } from '@/ECS4/data/fee';
  import { jobList, jobTypes, jobTypeList } from '@/ECS4/data/jobList';
  import { unitList } from '@/ECS4/data/unit';
  import Card from '@/ECS4/components/Card.vue';
  import TableCard from '@/ECS4/shows/TableCard.vue';
  import { test } from '@/ECS4';
  const { jobMap, unitMap, get } = test();
  // 高亮列表-职业
  const lightJobMap = ref(new Set());
  // 高亮列表-费用
  const lightFeeMap = ref(new Set());
  // 高亮列表-类型
  const lightTypeMap = ref(new Set());
  const t = {
    fee: 'fee',
    type: 'type',
  };
  function mouseenter(item, type) {
    if (type === t.fee) {
      lightFeeMap.value.add(item.value);
    } else if (type === t.type) {
      lightTypeMap.value.add(item.value);
    }
  }
  function mouseleave(item, type) {
    if (type === t.fee) {
      lightFeeMap.value.delete(item.value);
    } else if (type === t.type) {
      lightTypeMap.value.delete(item.value);
    }
  }
</script>

<style scoped lang="scss">
  $light: rgba(61, 61, 61, 0.9);
  .home {
    color: #fff;
    width: 100vw;
    height: 100vh;
    background-color: #0c0c0c;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;

    .flex {
      display: flex;
    }
    .mb-gap {
      margin-bottom: 8px;
    }
  }
</style>
